Module to pass Safetynet on Moto G 2015.
You can also customise the fingerprint being set to something you want.
1. Just navigate to common/system.prop and change the value of the fingerprint to anything you like(albeit it should be a valid one )
2. Then just compress everything into a new ".zip" file and your new module is ready.
Any fingerprint value should work as long as it is a valid fingerprint. Should work on Merlin(Moto G Turbo) devices too.